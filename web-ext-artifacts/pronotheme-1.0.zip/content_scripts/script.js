Element.prototype.remove = function() {
    this.parentElement.removeChild(this);
}

let url = window.location.href;


// remove scroll
document.documentElement.style.overflow = 'hidden';


function message(request, sender, sendResponse) {
    if (request) {
        try {
            document.getElementById('pronothemeDarkMode').remove();
        } catch (error) {

        }
        var cssLink = browser.extension.getURL("content_scripts/style.css");
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = cssLink;
        link.id = 'pronothemeDarkMode';
        document.head.appendChild(link);
    } else {
        try {
            document.getElementById('pronothemeDarkMode').remove();
        } catch (error) {

        }
    }
}

// wait for popup's instructions
browser.runtime.onMessage.addListener(message);


function checkStoredSettings(storedSettings) {
    if ((storedSettings.darkMode !== false) && (storedSettings.darkMode !== true)) {
        browser.storage.local.set({darkMode: false});
    }
    message(storedSettings.darkMode);
}

function onError(e) {
    console.error(e);
}

const gettingStoredSettings = browser.storage.local.get();
gettingStoredSettings.then(checkStoredSettings, onError);